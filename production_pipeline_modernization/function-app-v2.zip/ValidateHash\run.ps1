using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

# Initialize response
$statusCode = [HttpStatusCode]::OK
$body = @{}

try {
    # Get environment variables
    $storageConnectionString = $env:DATA_STORAGE_CONNECTION_STRING
    $dflinkContainer = $env:DFLINK_CONTAINER_NAME
    $archiveContainer = $env:ARCHIVE_CONTAINER_NAME
    $validationTempContainer = $env:VALIDATION_TEMP_CONTAINER_NAME

    Write-Host "Environment variables loaded successfully"

    # Parse request body
    $eventGridEvent = $Request.Body

    # Check if this is an Event Grid validation request
    if ($eventGridEvent -and $eventGridEvent[0].eventType -eq 'Microsoft.EventGrid.SubscriptionValidationEvent') {
        Write-Host "Event Grid subscription validation request received"
        $validationCode = $eventGridEvent[0].data.validationCode
        $body = @{ validationResponse = $validationCode }
        $statusCode = [HttpStatusCode]::OK
    }
    # Check if this is a blob created event
    elseif ($eventGridEvent -and $eventGridEvent[0].eventType -eq 'Microsoft.Storage.BlobCreated') {
        Write-Host "Blob created event received"

        $blobUrl = $eventGridEvent[0].data.url
        $blobName = $eventGridEvent[0].data.url -replace '.*/', ''

        Write-Host "Processing ZIP file: $blobName"
        Write-Host "Blob URL: $blobUrl"

        # ===================================================================
        # FULL VALIDATION LOGIC IMPLEMENTATION
        # ===================================================================

        # Create temp directory for processing
        $tempDir = Join-Path $env:TEMP "hash_validation_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
        New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
        Write-Host "Created temp directory: $tempDir"

        try {
            # Extract storage account name from connection string
            if ($storageConnectionString -match 'AccountName=([^;]+)') {
                $storageAccountName = $Matches[1]
            } else {
                throw "Could not extract storage account name from connection string"
            }

            # Create storage context
            $context = New-AzStorageContext -ConnectionString $storageConnectionString
            Write-Host "Storage context created successfully"

            # Step 1: Download ZIP file from dflink
            $zipFilePath = Join-Path $tempDir $blobName
            Write-Host "Downloading ZIP file to: $zipFilePath"

            Get-AzStorageBlobContent `
                -Container $dflinkContainer `
                -Blob $blobName `
                -Destination $zipFilePath `
                -Context $context `
                -Force | Out-Null

            Write-Host "ZIP file downloaded successfully (Size: $((Get-Item $zipFilePath).Length) bytes)"

            # Step 2: Download corresponding hash file
            $hashFileName = $blobName -replace '\.zip$', '.hash'
            $hashFilePath = Join-Path $tempDir $hashFileName
            Write-Host "Downloading hash file: $hashFileName"

            Get-AzStorageBlobContent `
                -Container $dflinkContainer `
                -Blob $hashFileName `
                -Destination $hashFilePath `
                -Context $context `
                -Force | Out-Null

            Write-Host "Hash file downloaded successfully (Size: $((Get-Item $hashFilePath).Length) bytes)"

            # Step 3: Extract ZIP file
            $extractDir = Join-Path $tempDir "extracted"
            New-Item -ItemType Directory -Path $extractDir -Force | Out-Null
            Write-Host "Extracting ZIP to: $extractDir"

            Expand-Archive -Path $zipFilePath -DestinationPath $extractDir -Force

            $extractedFiles = Get-ChildItem -Path $extractDir -Recurse -File
            Write-Host "Extracted $($extractedFiles.Count) files"

            # Step 4: Run hash.ps1 validation
            $hashScriptPath = Join-Path $PSScriptRoot "hash.ps1"
            $validationOutputFile = Join-Path $tempDir "validation_results.txt"

            Write-Host "Running hash validation script..."
            Write-Host "Hash script: $hashScriptPath"
            Write-Host "Hash file: $hashFilePath"
            Write-Host "Extract dir: $extractDir"

            # Run validation and capture output
            $validationProcess = Start-Process -FilePath "powershell.exe" `
                -ArgumentList "-ExecutionPolicy Bypass -File `"$hashScriptPath`" -Mode Validate -HashFile `"$hashFilePath`" -RootPath `"$extractDir`" -OutputFile `"$validationOutputFile`" -Silent" `
                -Wait -PassThru -NoNewWindow

            $exitCode = $validationProcess.ExitCode
            Write-Host "Validation script exit code: $exitCode"

            # Read validation output
            $validationOutput = ""
            if (Test-Path $validationOutputFile) {
                $validationOutput = Get-Content $validationOutputFile -Raw
                Write-Host "Validation output:`n$validationOutput"
            }

            # Step 5: Parse results
            $validationResult = @{
                exitCode = $exitCode
                timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
                zipFile = $blobName
                hashFile = $hashFileName
                filesExtracted = $extractedFiles.Count
            }

            # Extract summary from validation output
            if ($validationOutput -match 'SUMMARY: OK=(\d+) FAIL=(\d+) MISSING=(\d+) EXTRA=(\d+)') {
                $validationResult.okCount = [int]$Matches[1]
                $validationResult.failCount = [int]$Matches[2]
                $validationResult.missingCount = [int]$Matches[3]
                $validationResult.extraCount = [int]$Matches[4]
            }

            # Determine overall status based on exit code
            # Exit code 0 = Success
            # Exit code 3 = Validation issues (FAIL/MISSING/EXTRA files)
            # Exit code 2 = File/folder not found
            # Exit code 1 = Usage/parameter error

            if ($exitCode -eq 0) {
                $validationResult.status = "PASS"
                $validationResult.message = "All files validated successfully"

                # Step 6: Move to archive on success (optional)
                Write-Host "Validation PASSED - Files are valid"

                # TODO: Implement archiving logic
                # Copy-AzStorageBlob to archive container

            } elseif ($exitCode -eq 3) {
                $validationResult.status = "FAIL"
                $validationResult.message = "Validation failed: Hash mismatch or file discrepancies found"
                Write-Host "Validation FAILED - Hash mismatches detected" -ForegroundColor Yellow

            } elseif ($exitCode -eq 2) {
                $validationResult.status = "ERROR"
                $validationResult.message = "Validation error: Required files or folders not found"
                Write-Host "Validation ERROR - Files not found" -ForegroundColor Red

            } else {
                $validationResult.status = "ERROR"
                $validationResult.message = "Validation error: Unexpected exit code $exitCode"
                Write-Host "Validation ERROR - Unexpected exit code" -ForegroundColor Red
            }

            $validationResult.validationDetails = $validationOutput

            # Build response
            $body = $validationResult

        } finally {
            # Step 7: Cleanup temp files
            if (Test-Path $tempDir) {
                Write-Host "Cleaning up temp directory: $tempDir"
                Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
                Write-Host "Cleanup completed"
            }
        }

        Write-Host "Validation process completed for: $blobName"
    }
    # Handle manual/test invocations
    else {
        Write-Host "Manual test invocation"
        $body = @{
            status = "success"
            message = "Hash validation function is running"
            timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
            environment = @{
                storageConfigured = ($null -ne $storageConnectionString)
                dflinkContainer = $dflinkContainer
                archiveContainer = $archiveContainer
                validationTempContainer = $validationTempContainer
            }
        }
    }

} catch {
    Write-Host "ERROR: $_"
    Write-Host "Stack Trace: $($_.ScriptStackTrace)"

    $statusCode = [HttpStatusCode]::InternalServerError
    $body = @{
        status = "error"
        message = $_.Exception.Message
        stackTrace = $_.ScriptStackTrace
        timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    }
}

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = $statusCode
    Body = ($body | ConvertTo-Json -Depth 10)
    Headers = @{
        "Content-Type" = "application/json"
    }
})
